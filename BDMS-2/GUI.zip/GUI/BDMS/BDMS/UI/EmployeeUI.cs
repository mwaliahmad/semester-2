﻿using BDMS.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BDMS.UI
{
    public partial class EmployeeUI : Form
    {
        private Employee E;
        public EmployeeUI(Employee E)
        {
            this.E = E;
            InitializeComponent();
            customizeDesign();
        }

        private void customizeDesign()
        {
            panel_Dmenu.Visible = false;
            panel_Rmenu.Visible = false;
        }
        private void hideSubmenu()
        {
            if (panel_Dmenu.Visible == true)
            {
                panel_Dmenu.Visible = false;
            }
            if (panel_Rmenu.Visible == true)
            {
                panel_Rmenu.Visible = false;
            }
        }
        private void showSubmenu(Panel M)
        {
            if (M.Visible == false)
            {
                hideSubmenu();
                M.Visible = true;
            }
            else
            {
                M.Visible = false;
            }
        }

        private void btn_donor_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_Dmenu);
        }
        private void btn_AddD_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            AddPerson addPerson = new AddPerson(E, true);
            setForm(addPerson);
        }

        private void btn_delD_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            DeletePerson deletePerson = new DeletePerson(E, true);
            setForm(deletePerson);
        }

        private void btn_uptD_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            UpdatePerson updatePerson = new UpdatePerson(E, true);
            setForm(updatePerson);
        }

        private void btn_searchD_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            SearchPerson searchPerson = new SearchPerson(E, true);
            setForm(searchPerson);
        }

        private void btn_viewD_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            ViewPerson viewPerson = new ViewPerson(E, true, false);
            setForm(viewPerson);
        }

        private void btn_recipient_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_Rmenu);
        }

        private void btn_addR_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            AddPerson addPerson = new AddPerson(E, false);
            setForm(addPerson);
        }

        private void btn_delR_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            DeletePerson deletePerson = new DeletePerson(E, false);
            setForm(deletePerson);
        }

        private void btn_uptR_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            UpdatePerson updatePerson = new UpdatePerson(E, false);
            setForm(updatePerson);
        }

        private void btn_searchR_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            SearchPerson searchPerson = new SearchPerson(E, false);
            setForm(searchPerson);
        }

        private void btn_viewR_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            ViewPerson viewPerson = new ViewPerson(E, false, false);
            setForm(viewPerson);
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.Show();
        }

        private void EmployeeUI_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }
        private void setForm(Form form)
        {
            panel_main.Controls.Clear();
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            panel_main.Controls.Add(form);
            panel_main.Tag = form;
            form.BringToFront();
            form.Show();
        }
    }
}
