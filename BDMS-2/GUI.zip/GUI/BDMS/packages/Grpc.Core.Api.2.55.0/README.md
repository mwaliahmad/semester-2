# Grpc.Core.Api

`Grpc.Core.Api` is the shared API package for gRPC C# and gRPC for .NET implementations of gRPC.
