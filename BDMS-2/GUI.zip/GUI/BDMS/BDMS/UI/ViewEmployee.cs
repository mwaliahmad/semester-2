﻿using BDMS.BL;
using BDMS.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BDMS.UI
{
    public partial class ViewEmployee : Form
    {
        public ViewEmployee()
        {
            InitializeComponent();
            Databind();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Databind()
        {
            List<Employee> list = EmployeeCRUD.GetList();
            if (list.Count > 0)
            {
                GV.DataSource = null;
                foreach (Employee person in list)
                {
                    GV.DataSource = list.Select(a => new { a.Name1, a.Age1, a.Contact1, a.Cnic1, a.Username, a.Password }).ToList();
                }
                GV.DataSource = list;
                GV.Columns[0].HeaderText = "Name";
                GV.Columns[1].HeaderText = "Age";
                GV.Columns[2].HeaderText = "Contact";
                GV.Columns[3].HeaderText = "CNIC";
                GV.Refresh();
            }

            else
            {
                MessageBox.Show("Not Found Add First to View");
            }
        }

        private void btn_pdf_Click(object sender, EventArgs e)
        {
            PdfGenerator.GeneratePdfReport(EmployeeCRUD.GetList());
            MessageBox.Show("Downloaded Successfully");
            this.Hide();
        }
    }
}
